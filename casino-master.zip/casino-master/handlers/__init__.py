# Rewrite by: https://t.me/kawaiifamily
from .chats import dp
from .users import dp


__all__ = ["dp"]
