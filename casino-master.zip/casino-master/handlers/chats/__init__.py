# Rewrite by: https://t.me/kawaiifamily
from .dice_games import dp
from .add_chat_handler import dp


__all__ = ["dp"]
