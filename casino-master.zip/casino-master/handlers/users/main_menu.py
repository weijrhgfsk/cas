# Rewrite by: https://t.me/kawaiifamily
from aiogram.types import Message, CallbackQuery, InputFile

from config import config
from data.functions.db import get_user
from aiogram.dispatcher import FSMContext
from filters.filters import IsPrivate, IsPrivateCall
from keyboards.inline.other_keyboards import  cabinet_keyboard, chat_button
from keyboards.inline.games_keyboard import game_menu_keyboard
from loader import dp, bot
from texts import cabinet_text
import sqlite3
from data.functions.db import update_balance


@dp.message_handler(IsPrivate(), text="💰 PROFILE")
async def game_menu(message: Message):
    if get_user(message.chat.id) != None:
        await message.answer(cabinet_text(get_user(message.chat.id)),
                             reply_markup=cabinet_keyboard())

@dp.message_handler(text=["/бал", "/bal", "/balance", "/баланс"])
async def bal_check(message: Message):
    if get_user(message.from_user.id) != None:
        db = sqlite3.connect('data/database.db')
        cursor = db.cursor()
        cursor.execute("SELECT balance FROM users WHERE user_id = ?", (message.chat.id,))
        await message.answer("Ваш баланс: \n\n" + str(get_user(message.from_user.id)[1]) + " DAFFCoin")

@dp.message_handler(text=['/delete', '/del', '/удалить', '/удали', '/del'])
async def delete_game(message: Message):
    if get_user(message.from_user.id) != None:
        db = sqlite3.connect('data/database.db')
        cursor = db.cursor()
        try:
            cursor.execute('SELECT id, bet FROM chat_dice_games WHERE player_id_1 = ? AND message_id = ?', (message.from_user.id, message.reply_to_message.message_id))
            result = cursor.fetchone()

            if result:
                ananas, aboba = result

                cursor.execute(f"UPDATE users SET balance = balance + ? WHERE user_id = ?", (aboba, message.from_user.id,))
                db.commit()

                cursor.execute("DELETE FROM chat_dice_games WHERE player_id_1 = ? AND message_id = ?", (message.from_user.id, message.reply_to_message.message_id))
                db.commit()


                await bot.delete_message(message.chat.id, message.reply_to_message.message_id)
                await message.answer("Игра успешно удалена!")
            else:
                await message.answer("Игра не найдена или у вас нет прав на удаление этой игры.")
        except Exception as e:
            print(e)
            await message.answer("Вы не можете удалить эту игру!")



@dp.message_handler(IsPrivate(), text="💬 CHAT 💬")
async def chat(message: Message):
    await message.answer("<b><i>Игровой чат с участниками бота🤖</i></b>", reply_markup=chat_button)


@dp.callback_query_handler(IsPrivateCall(), text="partners_menu")
async def partners_handler(call: CallbackQuery):

    me = await bot.get_me()
    await call.message.answer(
        f"👥 <b>Приглашайте своих друзей и знакомых и получайте{config('ref_percent')}%"
        " от суммы всех их пополнений</b>\n\n📢 Ваша реферальная ссылка ⬇"
        f"\nhttps://t.me/{me.username}?start={call.from_user.id}",
        parse_mode="HTML")


@dp.message_handler(IsPrivate(), text="🎲 GAMES")
@dp.callback_query_handler(IsPrivateCall(), text="games_main_menu")
async def game_main_handler(message: Message, state: FSMContext):
    await state.finish()
    if not isinstance(message, Message):
      await message.message.edit_caption(
        caption="""<b>🎲 Список игр:</b>""",
        reply_markup=game_menu_keyboard())
    else:
      await message.answer_photo(
            photo=InputFile('filaro.jpg'),
            caption="""<b>🎲 Список игр:</b>""",
            reply_markup=game_menu_keyboard(),
            parse_mode="HTML")


@dp.callback_query_handler(IsPrivateCall(), text="games_back_menu", state='*')
async def game_main_handler(c: CallbackQuery, state: FSMContext):
    await state.finish()
    await c.message.delete()
    await c.message.answer_photo(
            photo=InputFile('filaro.jpg'),
            caption="""<b>🎲 Список игр:</b>""",
            reply_markup=game_menu_keyboard(),
            parse_mode="HTML")
