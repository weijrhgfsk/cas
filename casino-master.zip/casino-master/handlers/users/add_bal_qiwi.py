# Rewrite by: https://t.me/kawaiifamily
from aiogram.dispatcher import FSMContext
from aiogram.types import CallbackQuery, Message
from aiogram import types


from config import config
from data.functions.db import get_user, add_stat, select_buy_stat, update_balance, delete_stat
from keyboards.inline.other_keyboards import check_menu, back_to_main_menu, cabinet_keyboard
from loader import dp, bot
from states.states import balance_states
from texts import cabinet_text


@dp.callback_query_handler(text="back_to_personal_account", state="*")
async def back_to_personal_account(call: CallbackQuery, state: FSMContext):
    await state.finish()
    await call.message.edit_text(cabinet_text(get_user(call.from_user.id)),
                                 reply_markup=cabinet_keyboard())


@dp.callback_query_handler(regexp="deposit:polyavtomat")
async def add_balance_qiwi_main(call: CallbackQuery):
    await call.message.edit_text("Напишите сумму, которую вы хотите пополнить."
                                 "\n❗️*Внимание*❗️\n`Минимальная сумма пополнения - 10₽`",
                                 parse_mode="MarkDown", reply_markup=back_to_main_menu)
    await balance_states.BS1.set()

@dp.callback_query_handler(lambda call: call.data.startswith("topup_user:"))
async def add_balance_qiwi_main(call: CallbackQuery):
    data_list = call.data.split(':')
    user_id = data_list[1]
    amount = data_list[2]
    update_balance(user_id, amount)
    await call.message.delete()
    await call.message.answer('✅ Баланс успешно пополнен')
    await bot.send_message(user_id, f'✅ Ваш баланс пополнен на `{amount}₽`', parse_mode='MarkDown')

@dp.callback_query_handler(text='deletetopup')
async def delete_topup(call: CallbackQuery):
    await call.message.delete()
    await call.message.answer('❌ Пополнение отменено')

@dp.message_handler(state=balance_states.BS1)
async def add_balance_sber(message: Message, state: FSMContext):
    if float(message.text) >= 10:
        await state.update_data(amount=float(message.text))
        await bot.send_message(message.chat.id,
                               f"*Для того, чтобы пополнить свой баланс на" 
                               f" {round(float(message.text), 2)}руб вам нужно:*\n\n"
                               f"💰Перевести - `{round(float(message.text), 2)}₽`\n"
                               f"💳На реквизиты - `+{config('SBER_ADDRESS')}`\nсбербанк\n"
                               f"После перевода отправьте скриншот сюда. При отправке отрисованного скриншота вы получаете бан.",
                               parse_mode="MarkDown")

        await balance_states.BS2.set()
    else:
        await message.answer("Неверное количество, попробуйте еще раз :)")
        
        

@dp.message_handler(state=balance_states.BS2, content_types=[types.ContentType.PHOTO, types.ContentType.VIDEO])
async def add_balance_sber2(message: Message, state: FSMContext):
    data = await state.get_data()
    amount = data["amount"]
    photo = message.photo[-1].file_id
    markup = types.InlineKeyboardMarkup()
    button1 = types.InlineKeyboardButton(text="Пополнить", callback_data=f"topup_user:{message.chat.id}:{amount}")
    button2 = types.InlineKeyboardButton(text="Отказ", callback_data="deletetopup")
    markup.add(button1, button2)
    await bot.send_photo(config('ADMIN_ID'), photo, caption=f"Пополнение баланса на {amount} рублей.", reply_markup=markup)
    await message.answer("💸 Спасибо за пополнение, ожидайте проверки администратором.")
    await state.finish()
